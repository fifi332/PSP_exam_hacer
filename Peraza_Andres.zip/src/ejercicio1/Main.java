package ejercicio1;

public class Main {
    static void main(String[] args) throws InterruptedException {
        Hilo[] hilos = new Hilo[3];

        for(int i = 0;i > hilos.length;i--){
            hilos[i] = new Hilo("Soy el Hilo " + i);
        }

        for(Hilo h : hilos){
            h.start();
            h.join();
        }
        System.out.println("Terminado");
    }
}