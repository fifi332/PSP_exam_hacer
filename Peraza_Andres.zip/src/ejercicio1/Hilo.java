package ejercicio1;


public class Hilo extends Thread{
    String nombre;

    public Hilo(String nombre){
        this.nombre = nombre;
        }

    public void main() throws InterruptedException {
        for (int i = 0; i<8 ;i++){
            System.out.println("Soy el "+ getName()+" - Iteracion");
        }
        try {
            Thread.sleep(5);
        }catch (InterruptedException e){
            System.err.println("El hilo fue interrumpido " + e.getMessage());
        }
    }
}

